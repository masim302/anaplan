const express = require('express')
const app = express()
const contentRouter = require('./src/controller/contentController');

app.use('/content', contentRouter)

app.all('*', function (req, res) {
  res.status(400).json({
    error: " Bad Request"
  });
});


app.listen(8080, function () {
  console.log('app listening on port 8080!')
})


module.exports = app;