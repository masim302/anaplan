use site;

CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cshid` longtext,
  `link` varchar(250),
  `resolve_id` varchar(100),
  `content_id` varchar(100),
  `anchor` varchar(100),
  `kentico_id` varchar(100),
  `locale` varchar(2),
  `codename` varchar(100),
  `type` varchar(100),
  `isPublished` tinyint(1) DEFAULT NULL,
  `modified` varchar(30),
  PRIMARY KEY (`id`),
  KEY `ix_title_pub` (`codename`,`isPublished`),
  KEY `ix_local_pub` (`locale`,`isPublished`)
);

CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext,
  `type` varchar(100),
  `codename` varchar(100),
  PRIMARY KEY (`id`),
  KEY `ix_codename` (`codename`)
);

CREATE TABLE `articles_elements` (
  `element_id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  PRIMARY KEY (`article_id`,`element_id`),
  KEY `ix_element_id` (`element_id`)
);


INSERT INTO `articles` (`id`, `cshid`, `link`, `resolve_id`, `content_id`, `anchor`, `kentico_id`, `locale`, `codename`, `type`, `isPublished`, `modified`) VALUES
('1', '1286,ABS-ta-p-17513', 'Calculation_Functions/All/ABS.html', '', NULL, NULL, '61bf5c03-456f-4179-9680-6c623ac7996c', 'en', 'abs', 'article', '1', 'Tue Nov 24 2020 13:21:08 GMT+0'),
('2', 'Add_Images_Dashboards.htm', 'Dashboards_and_Visualization/Build%20Dashboards/Add_Images_Dashboards.htm', '', NULL, NULL, '7cc99cef-ce1a-4dbc-b52e-fec500b90b96', 'en', 'add_images_to_dashboards', 'article', '1', 'Fri Sep 25 2020 08:26:18 GMT+0'),
('3', '1489,1488,The-Administration-Interface-ta-p-8414,Accessing-the-Anaplan-Administration-Tool-ta-p-8417', 'Administration_and_Security/Tenant_Administration/Accessing_Anaplan_Administration_Tool.html', '', NULL, NULL, '02f922f0-1229-4e48-9e3b-357a3d552ed7', 'en', 'access_the_anaplan_administration_console', 'article', '1', 'Thu Sep 10 2020 04:17:01 GMT+0');

INSERT INTO `articles_elements` (`element_id`, `article_id`) VALUES
('1', '1'),
('2', '1'),
('3', '1'),
('4', '1'),
('5', '1'),
('6', '1'),
('7', '1'),
('8', '1'),
('9', '1'),
('10', '1'),
('11', '2'),
('12', '2'),
('13', '2'),
('14', '2'),
('15', '2'),
('16', '2'),
('17', '2'),
('18', '2'),
('19', '2'),
('20', '2'),
('21', '3'),
('22', '3'),
('23', '3'),
('24', '3'),
('25', '3'),
('26', '3'),
('27', '3'),
('28', '3'),
('29', '3');

INSERT INTO `elements` (`id`, `content`, `type`, `codename`) VALUES
('1', 'ABS', 'text', 'title'),
('2', '%0A%3Cp%3EUse%20the%20ABS%20function%20to%20find%20the%20absolute%20value%20of%20a%20number.%3C%2Fp%3E%0A%3Cp%3EThe%20absolute%20value%20of%20a%20non-negative%20number%20(a%20positive%20number%2C%20or%20zero)%2C%20is%20the%20same%20number.%20For%20example%2C%20the%20absolute%20value%20of%204%20is%204.%3C%2Fp%3E%0A%3Cp%3EIf%20a%20number%20is%20negative%2C%20its%20absolute%20value%20is%20the%20same%20number%2C%20without%20the%20negative%20sign.%20For%20example%2C%20the%20absolute%20value%20of%20-3%20is%203.%3C%2Fp%3E%0A%3Ch2%3ESyntax%3C%2Fh2%3E%0A%3Cp%20class%3D%22notranslate%22%3E%3Cspan%20class%3D%22notranslate%22%3EABS(number)%3C%2Fspan%3E%0A%3C%2Fp%3E%0A%3Cp%3EThe%20ABS%20function%20has%20the%20following%20arguments.%3C%2Fp%3E%0A%3Ctable%20style%3D%22border-left-style%3A%20none%3Bborder-left-width%3A%200px%3Bborder-right-style%3A%20none%3Bborder-right-width%3A%200px%3Bborder-top-style%3A%20none%3Bborder-top-width%3A%201px%3Bborder-bottom-style%3A%20none%3Bborder-bottom-width%3A%201px%3Bmargin-left%3A%200%3Bmargin-right%3A%20auto%3Bmc-table-style%3A%20url(&#039;..%2F..%2FResources%2FTableStyles%2FFormulaTable.css&#039;)%3B%22%20class%3D%22TableStyle-FormulaTable%22%20cellspacing%3D%220%22%3E%0A%0A%0A%0A%20%20%3Cthead%3E%0A%20%20%20%20%3Ctr%20class%3D%22TableStyle-FormulaTable-Head-Header1%22%3E%0A%20%20%20%20%20%20%3Cth%20class%3D%22TableStyle-FormulaTable-HeadE-Column1-Header1%22%3EArgument%3C%2Fth%3E%0A%20%20%20%20%20%20%3Cth%20class%3D%22TableStyle-FormulaTable-HeadE-Column1-Header1%22%3EData%20type%3C%2Fth%3E%0A%20%20%20%20%20%20%3Cth%20class%3D%22TableStyle-FormulaTable-HeadD-Column1-Header1%22%3EDescription%3C%2Fth%3E%0A%20%20%20%20%3C%2Ftr%3E%0A%20%20%3C%2Fthead%3E%0A%20%20%3Ctbody%3E%0A%20%20%20%20%3Ctr%20class%3D%22TableStyle-FormulaTable-Body-Body1%22%3E%0A%20%20%20%20%20%20%3Ctd%20class%3D%22TableStyle-FormulaTable-BodyB-Column1-Body1%22%3E%3Cspan%20class%3D%22notranslate%22%3Enumber%3C%2Fspan%3E%20(required)%3C%2Ftd%3E%0A%20%20%20%20%20%20%3Ctd%20class%3D%22TableStyle-FormulaTable-BodyB-Column1-Body1%22%3E%0A%20%20%20%20%20%20%20%20%3Cp%3ENumber%3C%2Fp%3E%0A%20%20%20%20%20%20%3C%2Ftd%3E%0A%20%20%20%20%20%20%3Ctd%20class%3D%22TableStyle-FormulaTable-BodyA-Column1-Body1%22%3E%0A%20%20%20%20%20%20%20%20%3Cp%3EThe%20number%20you%20want%20to%20find%20the%20absolute%20value%20of.%3C%2Fp%3E%0A%20%20%20%20%20%20%3C%2Ftd%3E%0A%20%20%20%20%3C%2Ftr%3E%0A%20%20%3C%2Ftbody%3E%0A%3C%2Ftable%3E%0A%3Ch2%3EConstraints%3C%2Fh2%3E%0A%3Cp%3EThis%20function%20has%20no%20constraints.%3C%2Fp%3E%0A%3Ch2%3EExamples%3C%2Fh2%3E%0A%3Cp%3EThe%20following%20table%20shows%20some%20example%20formulas%20using%20the%20ABS%20function.%3C%2Fp%3E%0A%3Cp%3EYou%20can%20enter%20values%20directly%20into%20your%20formula%2C%20or%20reference%20line%20items%20or%20list%20properties.%3C%2Fp%3E%0A%3Ctable%20style%3D%22border-left-style%3A%20none%3Bborder-left-width%3A%200px%3Bborder-right-style%3A%20none%3Bborder-right-width%3A%200px%3Bborder-top-style%3A%20none%3Bborder-top-width%3A%201px%3Bborder-bottom-style%3A%20none%3Bborder-bottom-width%3A%201px%3Bmargin-left%3A%200%3Bmargin-right%3A%20auto%3Bmc-table-style%3A%20url(&#039;..%2F..%2FResources%2FTableStyles%2FFormulaTable.css&#039;)%3B%22%20class%3D%22TableStyle-FormulaTable%22%20cellspacing%3D%220%22%3E%0A%0A%0A%0A%20%20%3Cthead%3E%0A%20%20%20%20%3Ctr%20class%3D%22TableStyle-FormulaTable-Head-Header1%22%3E%0A%20%20%20%20%20%20%3Cth%20class%3D%22TableStyle-FormulaTable-HeadE-Column1-Header1%22%3EFormula%3C%2Fth%3E%0A%20%20%20%20%20%20%3Cth%20class%3D%22TableStyle-FormulaTable-HeadE-Column1-Header1%22%3EDescription%3C%2Fth%3E%0A%20%20%20%20%20%20%3Cth%20class%3D%22TableStyle-FormulaTable-HeadD-Column1-Header1%22%3EResult%3C%2Fth%3E%0A%20%20%20%20%3C%2Ftr%3E%0A%20%20%3C%2Fthead%3E%0A%20%20%3Ctbody%3E%0A%20%20%20%20%3Ctr%20class%3D%22TableStyle-FormulaTable-Body-Body1%22%3E%0A%20%20%20%20%20%20%3Ctd%20class%3D%22TableStyle-FormulaTable-BodyE-Column1-Body1%22%3E%3Cspan%20class%3D%22notranslate%22%3EABS(Product.Stock)%3C%2Fspan%3E%0A%20%20%20%20%20%20%3C%2Ftd%3E%0A%20%20%20%20%20%20%3Ctd%20class%3D%22TableStyle-FormulaTable-BodyE-Column1-Body1%22%3EThis%20example%20shows%20how%20you%20can%20include%20line%20items%20or%20list%20properties%20in%20your%20formula.%20In%20this%20example%2C%20the%20value%20of%20Product.Stock%20is%203.%3C%2Ftd%3E%0A%20%20%20%20%20%20%3Ctd%20class%3D%22TableStyle-FormulaTable-BodyD-Column1-Body1%22%3E%0A%20%20%20%20%20%20%20%20%3Cp%3E3%3C%2Fp%3E%0A%20%20%20%20%20%20%3C%2Ftd%3E%0A%20%20%20%20%3C%2Ftr%3E%0A%20%20%20%20%3Ctr%20class%3D%22TableStyle-FormulaTable-Body-Body1%22%3E%0A%20%20%20%20%20%20%3Ctd%20class%3D%22TableStyle-FormulaTable-BodyE-Column1-Body1%22%3E%3Cspan%20class%3D%22notranslate%22%3EABS(-20)%3C%2Fspan%3E%0A%20%20%20%20%20%20%3C%2Ftd%3E%0A%20%20%20%20%20%20%3Ctd%20class%3D%22TableStyle-FormulaTable-BodyE-Column1-Body1%22%3E%0A%20%20%20%20%20%20%20%20%3Cp%3EThe%20absolute%20value%20of%20-20.%3C%2Fp%3E%0A%20%20%20%20%20%20%3C%2Ftd%3E%0A%20%20%20%20%20%20%3Ctd%20class%3D%22TableStyle-FormulaTable-BodyD-Column1-Body1%22%3E%0A%20%20%20%20%20%20%20%20%3Cp%3E20%3C%2Fp%3E%0A%20%20%20%20%20%20%3C%2Ftd%3E%0A%20%20%20%20%3C%2Ftr%3E%0A%20%20%20%20%3Ctr%20class%3D%22TableStyle-FormulaTable-Body-Body1%22%3E%0A%20%20%20%20%20%20%3Ctd%20class%3D%22TableStyle-FormulaTable-BodyB-Column1-Body1%22%3E%3Cspan%20class%3D%22notranslate%22%3EABS(-412.3912)%3C%2Fspan%3E%0A%20%20%20%20%20%20%3C%2Ftd%3E%0A%20%20%20%20%20%20%3Ctd%20class%3D%22TableStyle-FormulaTable-BodyB-Column1-Body1%22%3E%0A%20%20%20%20%20%20%20%20%3Cp%3EThe%20absolute%20value%20of%20-412.3912.%3C%2Fp%3E%0A%20%20%20%20%20%20%3C%2Ftd%3E%0A%20%20%20%20%20%20%3Ctd%20class%3D%22TableStyle-FormulaTable-BodyA-Column1-Body1%22%3E412.3912%0A%20%20%20%20%20%20%3C%2Ftd%3E%0A%20%20%20%20%3C%2Ftr%3E%0A%20%20%3C%2Ftbody%3E%0A%3C%2Ftable%3E%0A%3Ch2%3EExcel%20equivalent%3C%2Fh2%3E%0A%3Cp%3E%3Ca%20href%3D%22https%3A%2F%2Fsupport.office.com%2Fen-gb%2Farticle%2FABS-function-3420200f-5628-4e8c-99da-c99d7c87713c%22%3EABS%3C%2Fa%3E%0A%3C%2Fp%3E', 'custom', 'html_content'),
('3', 'TECHNO-394', 'text', 'jira_issue__jira_issue'),
('4', 'abs', 'taxonomy', 'site_map__table_of_contents_'),
('5', 'calculation_functions', 'taxonomy', 'feature_name'),
('6', '', 'text', 'legacy_url_routing__kentico_id'),
('7', 'Calculation_Functions%2FAll%2FABS.html', 'text', 'legacy_url_routing__url'),
('8', '', 'text', 'legacy_url_routing__anchors'),
('9', 'ABS-ta-p-17513', 'text', 'legacy_url_routing__alphanumeric_cshid'),
('10', '1286', 'text', 'legacy_url_routing__numeric_cshid'),
('11', 'Add%20Images%20to%20Dashboards', 'text', 'title'),
('12', '%0D%0A%3Cp%3EYou%20can%20include%20multiple%20images%20in%20a%20dashboard%20using%20the%20image%20placeholder%20dashboard%20element.%20Images%20on%20dashboards%20are%20especially%20useful%20for%20helping%20users%20to%20identify%20products%20by%20their%20image%2C%20rather%20than%20by%20a%20product%20code%20or%20SKU.%3C%2Fp%3E%0D%0A%3Cp%3E%0D%0A%20%20%3Cimg%20src%3D%22https%3A%2F%2Fassets-us-01.kc-usercontent.com%2Fcddce937-cf5a-003a-bfad-78b8fc29ea3f%2F522e38e2-0f5a-4447-8ba4-7c7096548468%2FDashboardImageShoeExample.png%22%20%2F%3E%0D%0A%3C%2Fp%3E%0D%0A%3Cp%3EBefore%20inserting%20images%2C%20you%20must%20first%20create%20line%20items%20that%20contain%20or%20reference%20the%20URLs%20of%20the%20images%20you%20want%20to%20display.%20These%20line%20items%20must%20be%20formatted%20as%20%3Cstrong%3EText%3C%2Fstrong%3E%20and%20have%20a%20type%20of%20%3Cstrong%3ELink%3C%2Fstrong%3E.%20Image%20URLs%20can%20be%20added%20to%20lists%20as%20properties%20and%20then%20referenced%20in%20a%20module%20%E2%80%94%20for%20more%20information%2C%20see%3Ca%20href%3D%22%23Storing%22%3EManage%20product%20images%20in%20a%20centralized%20module%3C%2Fa%3E.%3C%2Fp%3E%0D%0A%3Cdiv%20class%3D%22portlet-msg-info%22%3E%3Cstrong%3ENote%3A%3C%2Fstrong%3EImages%20on%20dashboards%20are%20linked%20rather%20than%20embedded%20%E2%80%94%20every%20time%20a%20dashboard%20is%20refreshed%2C%20the%20latest%20version%20of%20the%20image%20is%20loaded.%20Images%20must%20be%20securely%20hosted%20%E2%80%94%20the%20image%20URL%26%23160%3Bmust%20begin%20with%3Ccode%3Ehttps%3A%2F%2F%3C%2Fcode%3E%E2%80%94%20and%20end%20with%20the%20image%20type%20PNG%2C%20JPG%2C%20JPEG%2C%20or%20GIF.%20Images%20on%20dashboards%20are%20not%20included%20when%20exporting%20dashboards%20to%20PDF%20(white%20space%20is%20displayed%20instead).%3C%2Fdiv%3E%0D%0A%3Ch2%3EAdd%20an%20image%20to%20a%20dashboard%3C%2Fh2%3E%0D%0A%3Col%3E%0D%0A%20%20%3Cli%20value%3D%221%22%3EIn%20the%20dashboard%2C%20open%20the%20Dashboard%20Designer%20by%20clicking%20%3Cstrong%3EEdit%3C%2Fstrong%3E.%3C%2Fli%3E%0D%0A%20%20%3Cli%20value%3D%222%22%3EClick%20%3Cstrong%3EAdd%20Image%3C%2Fstrong%3E.%3C%2Fli%3E%0D%0A%20%20%3Cp%3EThe%20image%20placeholder%20element%20is%20added%20to%20the%20bottom%20of%20the%20canvas%3A%3C%2Fp%3E%0D%0A%20%20%3Cp%3E%0D%0A%20%20%20%20%3Cimg%20src%3D%22https%3A%2F%2Fassets-us-01.kc-usercontent.com%2Fcddce937-cf5a-003a-bfad-78b8fc29ea3f%2F894a5aac-cfcd-4c55-bc99-c18d33d89e15%2FImagePlaceholderElement.png%22%20%2F%3E%0D%0A%20%20%3C%2Fp%3E%0D%0A%20%20%3Cli%20value%3D%223%22%3EIf%20the%20Properties%20panel%20is%20not%20already%20open%2C%20click%20the%20%3Cstrong%3EOpen%20Properties%20Panel%3C%2Fstrong%3E%3Cimg%20src%3D%22https%3A%2F%2Fassets-us-01.kc-usercontent.com%2Fcddce937-cf5a-003a-bfad-78b8fc29ea3f%2F5d3d6cfb-58fc-4901-9d2a-27ae743cee45%2FOpenPropertiesPanelIcon.png%22%20alt%20title%20style%3D%22vertical-align%3A%20baseline%3B%22%20%2F%3E%20icon.%3C%2Fli%3E%0D%0A%20%20%3Cli%20value%3D%224%22%3EIn%20the%20Image%20section%20of%20the%20Properties%20panel%2C%20click%20%3Cstrong%3ESelect%20line%20item%3C%2Fstrong%3E%20and%20then%20select%20the%20module%20and%20line%20item%20that%20contains%20or%20references%20the%20image%20you%20want%20to%20add.%3C%2Fli%3E%0D%0A%20%20%3Cp%3E%0D%0A%20%20%20%20%3Cimg%20src%3D%22https%3A%2F%2Fassets-us-01.kc-usercontent.com%2Fcddce937-cf5a-003a-bfad-78b8fc29ea3f%2Fdfca94a2-e2e3-4bb3-b231-1b869adb7113%2FPropsPanelImageOptions.png%22%20%2F%3E%0D%0A%20%20%3C%2Fp%3E%0D%0A%20%20%3Cp%3EThe%20linked%20image%20is%20loaded%20in%20the%20image%20placeholder%20element.%20If%20the%20image%20is%20unavailable%20%E2%80%94%20because%20the%20network%20connection%20is%20lost%2C%20or%20the%20image%20isn%E2%80%99t%20on%20the%20server%20%E2%80%94%20a%20white%20space%20is%20displayed.%3C%2Fp%3E%0D%0A%20%20%3Cli%20value%3D%225%22%3EIn%20the%20Height%20and%20Width%20section%2C%20use%20the%20%3Cstrong%3EPercentage%3C%2Fstrong%3E%20or%20%3Cstrong%3EPixels%3C%2Fstrong%3E%20options%20to%20view%20and%20adjust%20the%20dimensions%20of%20the%20image%20placeholder%20element.%20You%20can%20also%20drag%20the%20arrowhead%20in%20the%20bottom-right%20corner%20of%20the%20image%20placeholder%20element%20to%20resize%20it%20(the%20aspect%20ratio%20of%20the%20image%20is%20always%20maintained).%3C%2Fli%3E%0D%0A%20%20%3Cli%20value%3D%226%22%3ETo%20add%20the%20image%2C%20click%20%3Cstrong%3ESave%3C%2Fstrong%3E%20or%20%3Cstrong%3ESave%20%26amp%3B%20Exit%3C%2Fstrong%3E%20on%20the%20dashboard%20toolbar.%3C%2Fli%3E%0D%0A%20%20%3Cdiv%20class%3D%22portlet-msg-info%22%3E%3Cstrong%3ENote%3A%3C%2Fstrong%3E%20If%20the%20selected%20line%20item%20doesn&#039;t%20contain%20or%20reference%20a%20valid%20image%20URL%2C%20an%20error%20message%20is%20displayed%20in%20the%20image%20placeholder.%3C%2Fdiv%3E%0D%0A%3C%2Fol%3E%0D%0A%3Cp%3EFor%20more%20information%20on%20resizing%20dashboard%20images%2C%20see%20%3Ca%20href%3D%22%2FDashboards_and_Visualization%2FBuild%20Dashboards%2FHeight_and_Width.html%22%3EHeight%20and%20Width%3C%2Fa%3E.%3C%2Fp%3E%0D%0A%3Ch2%3E%3Ca%20name%3D%22Storing%22%3E%3C%2Fa%3EManage%20product%20images%20in%20a%20centralized%20module%3C%2Fh2%3E%0D%0A%3Cp%3EIf%20you&#039;re%20using%20images%20on%20dashboards%20to%20display%20product%20images%2C%20we%20recommend%20that%20you%20manage%20the%20product%20image%20URLs%20and%20product%20information%20in%20one%20centralized%20module.%20That%20way%2C%20any%20change%20to%20a%20product%20image%20is%20reflected%20in%20all%20other%20modules%20that%20reference%20the%20centralized%20module.%20%3C%2Fp%3E%0D%0A%3Cp%3EUsing%20a%20centralized%20module%20to%20store%20product%20image%20URLs%20has%20the%20following%20advantages%3A%3C%2Fp%3E%0D%0A%3Cul%3E%0D%0A%20%20%3Cli%20value%3D%221%22%3EIt&#039;s%20easier%20to%20trace%20the%20line%20item%20through%20the%20model%20map%3C%2Fli%3E%0D%0A%20%20%3Cli%20value%3D%222%22%3EThe%20content%20can%20be%20filtered%20in%20the%20module%3C%2Fli%3E%0D%0A%20%20%3Cli%20value%3D%223%22%3ESummary%20options%20are%20available%3C%2Fli%3E%0D%0A%20%20%3Cli%20value%3D%224%22%3EThe%20Formula%20Bar%20won&#039;t%20be%20empty%20if%20there&#039;s%20an%20error%20while%20constructing%20a%20formula%3C%2Fli%3E%0D%0A%3C%2Ful%3E%0D%0A%3Cp%3EYou%20can%20add%20a%20formula%20that%20returns%20the%20image%20URL%20as%20a%20line%20item%20value%20in%20a%20reference%20module.%20When%20the%20module%20is%20published%20to%20a%20dashboard%2C%20you%20can%20add%20an%20image%20placeholder%20that%20displays%20the%20linked%20image.%20This%20helps%20users%20identify%20the%20product.%3C%2Fp%3E%0D%0A%3Cp%3EIn%20this%20example%2C%20we%20have%20a%20list%2C%20%3Cstrong%3EProductImageURLs%3C%2Fstrong%3E%2C%20with%20a%20property%2C%20%3Cstrong%3EImageURL%3C%2Fstrong%3E%2C%20that%20holds%20the%20URL%20for%20the%20image.%3C%2Fp%3E%0D%0A%3Cp%3EThe%20module%20%3Cstrong%3ERetail%20Products%3C%2Fstrong%3E%20displays%20the%20%3Cstrong%3EProductImageURLs%3C%2Fstrong%3E%20list%20on%20rows%2C%20and%20line%20items%20in%20columns.%3C%2Fp%3E%0D%0A%3Cp%3EThe%20line%20item%2C%20%3Cstrong%3EImage%3C%2Fstrong%3E%2C%20contains%20the%20formula%20%3Cstrong%3EProductImageURLs.Image%20URL%3C%2Fstrong%3E%20to%20return%20the%20image%20property%20for%20each%20item%20in%20the%20%3Cstrong%3EProductImageURLs%3C%2Fstrong%3E%20list.%3C%2Fp%3E%0D%0A%3Cp%3E%0D%0A%20%20%3Cimg%20src%3D%22https%3A%2F%2Fassets-us-01.kc-usercontent.com%2Fcddce937-cf5a-003a-bfad-78b8fc29ea3f%2Fb57c396f-2cc5-482f-801d-dca5084fef4d%2FProductModule.png%22%20%2F%3E%0D%0A%3C%2Fp%3E', 'custom', 'html_content'),
('13', '', 'text', 'jira_issue__jira_issue'),
('14', 'add_images_to_dashboards', 'taxonomy', 'site_map__table_of_contents_'),
('15', 'dashboards', 'taxonomy', 'feature_name'),
('16', '', 'text', 'legacy_url_routing__kentico_id'),
('17', 'Dashboards_and_Visualization%2FBuild%2520Dashboards%2FAdd_Images_Dashboards.htm', 'text', 'legacy_url_routing__url'),
('18', '', 'text', 'legacy_url_routing__anchors'),
('19', 'Add_Images_Dashboards.htm', 'text', 'legacy_url_routing__alphanumeric_cshid'),
('20', '', 'text', 'legacy_url_routing__numeric_cshid'),
('21', '%0D%0A%09%09%09Access%20the%20Anaplan%20Administration%20console', 'text', 'title'),
('22', '%3Ch1%3E%0D%0A%20%20Access%20the%20Anaplan%20Administration%20console%3C%2Fh1%3E%0D%0A%3Cp%3EIf%20you%20have%20the%20%3Ca%20href%3D%22%2FAdministration_and_Security%2FTenant_Administration.html%23RolesAccessAdmin%22%3Eappropriate%20role%3C%2Fa%3E%2C%20you%20can%20access%20the%20Administration%20console%20one%20of%20two%20ways%3A%3C%2Fp%3E%0D%0A%3Cul%3E%0D%0A%20%20%3Cli%20value%3D%221%22%3EEnter%20%3Ca%20href%3D%22https%3A%2F%2Fadministration.anaplan.com%2F%22%3Ehttps%3A%2F%2Fadministration.anaplan.com%3C%2Fa%3E%20and%20log%20in%20using%20your%20Anaplan%20credentials.%3C%2Fli%3E%0D%0A%20%20%3Cdiv%20class%3D%22portlet-msg-info%22%3EIf%20you&#039;re%20already%20logged%20into%20Anaplan%2C%20you%20won&#039;t%20need%20to%20re-enter%20your%20username%20and%20password.%3Cbr%20%2F%3E%3C%2Fdiv%3E%0D%0A%20%20%3Cimg%20src%3D%22https%3A%2F%2Fassets-us-01.kc-usercontent.com%2Fcddce937-cf5a-003a-bfad-78b8fc29ea3f%2Fee118e8d-b533-4969-88ee-4434b08ef48e%2FAnaplanAdminURLBrowser.png%22%20alt%3D%22Administration%20URL%20in%20Browser%20Address%20bar%22%20%2F%3E%0D%0A%20%20%3Cli%20value%3D%222%22%3ELog%20in%20to%20%3Cspan%20class%3D%22AnapediaVariablesCompanyNameShort%22%3EAnaplan%3C%2Fspan%3E%20and%20then%20select%20%3Cstrong%3EAdministration%3C%2Fstrong%3E%20from%20the%20Application%20menu%20in%20the%20top-left%20corner.%3C%2Fli%3E%0D%0A%20%20%3Cimg%20src%3D%22https%3A%2F%2Fassets-us-01.kc-usercontent.com%2Fcddce937-cf5a-003a-bfad-78b8fc29ea3f%2Fb0e52d76-252f-4daa-b702-818629ed590e%2FApplicationMenuAdministration.png%22%20alt%3D%22Adminstration%20App%20listed%20on%20menu%20app%22%20%2F%3E%0D%0A%3C%2Ful%3E', 'custom', 'html_content'),
('23', '', 'text', 'jira_issue__jira_issue'),
('24', 'access_the_anaplan_administration_console', 'taxonomy', 'site_map__table_of_contents_'),
('25', 'administration', 'taxonomy', 'feature_name'),
('26', '', 'text', 'legacy_url_routing__kentico_id'),
('27', 'Administration_and_Security%2FTenant_Administration%2FAccessing_Anaplan_Administration_Tool.html', 'text', 'legacy_url_routing__url'),
('28', '', 'text', 'legacy_url_routing__anchors'),
('29', 'The-Administration-Interface-ta-p-8414%2CAccessing-the-Anaplan-Administration-Tool-ta-p-8417', 'text', 'legacy_url_routing__alphanumeric_cshid'),
('30', '1489%2C1488', 'text', 'legacy_url_routing__numeric_cshid');
