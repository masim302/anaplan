# Interview Test

## Introduction

Welcome to MagiDash Corp - Our mission is to provide relevant technical documentation to allow our customers to get the most out of our products. As such, we create rich and simple content to allow our customers to get the most out of our content.

To get the project started we want to be able to show a list of dummy content to users so that they can access a subset of our new content.

Provided is a docker based environment that uses [docker-compose](https://docs.docker.com/compose/) which contains a mysql container and an node container.

## Interview Task

Your task is to build an api service which implements a `/content` endpoint that returns a list of content article objects retrieved from the mysql database provided.

The expected format of the content object should be roughly
```json
{
  "kentico_id": <String>,
  "title": <String>,
  "html_content": <String>,
  "modified": <Date>,
  "isPublished": <Boolean>
}
```

The initial nodejs server code has been created for the api. This code can be found in index.js. During the onsite portion of the interview you will be expected to work through a set of stories which will evolve this api service to meet new requirements.

## Getting Started

### Prerequisites

Before running the environment you will need to ensure you have the required software installed.

Running `./check_prerequisites.sh` will check what software you need to install on your machine to get this working. Please ensure docker is up to date

### Running the environment

To run the environment, run `docker-compose up --force-recreate` in the terminal. This will bring up the terminal and the "fake" api service.

The api is available on `http://localhost/` and the mysql server is available on mysql:3306. These ports can be easily changed in the docker-compose.yml file if you wish.

### Working with the database

The seed scripts for the database are located in the `database` folder. When the database container is created, the
scripts will be run automatically. This includes the creation of the tables and some mock data.

To apply any script changes when the database is already running you will need to stop the running database container and destroy it. Running `docker-compose down` will stop the environment and destroy the containers for you, the next time you bring the environment up the containers will be created again.


***************************************************************************************************************************************

Note:MySQL Databse url in the docker should be the name of the container, I manually updated the url in the nodejs application which was `bring-your-own-interview_mysql-db_1` ( in my case ) once database was up and running, configration for the database stored in `config.json` file located in the root of the application. If nodejs application is runnig locally then it can connect to MySQL in Docker via `localhost`.
A better option would be using network bridge in Docker.  
# Solution 
## Assumptions

1. Data can either be filtered in SQL query or in the code.  

2. Below are the required fields expected in the json object, data must be filtered and structured before returning to the consumer

```json
{
  "kentico_id": <String>,
  "title": <String>,
  "html_content": <String>,
  "modified": <Date>,
  "isPublished": <Boolean>
}
```
### Unit Test
To run unit test, run command  `npm test` in the root directory of the application where `package.json` file is located.

#### API endpoint 
The application implements `/content` endpoint that returns a list of objects.
The endpoint `/content` takes an optional query string `decode` to deocde html_content before sending the respose


