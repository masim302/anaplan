#!/bin/bash

FAILED_PREREQUISITES=0

if ! command -v docker >/dev/null 2>&1; then
  echo "docker: MISSING" 1>&2
  echo "docker is required to run the development environment" 1>&2
  echo "Please visit https://docs.docker.com/install/ for instructions on how to install it for your platform" 1>&2
  echo "" 1>&2
  ((FAILED_PREREQUISITES++))
else
  echo "docker: FOUND" 1>&2
fi

if [[ $FAILED_PREREQUISITES -ne 0 ]]; then
  echo
  echo $FAILED_PREREQUISITES PREREQUISITES MISSING
  echo
  echo Please see the comments above for instructions on how to install the software required for this test.
  exit 1
else
  echo "Prerequisites passed"
fi
