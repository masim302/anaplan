exports.getContents = async function getContents() {
    const pool = require('../dbConnection/getDBConnection');
    let sqlQuery = `select 
    articles.kentico_id, 
    MAX(CASE when elements.codename ='title' then elements.content END) as title, 
    MAX(CASE when elements.codename ='html_content' then elements.content END) as html_content,
    articles.modified,
    CASE WHEN articles.isPublished = 1 THEN 'True' ELSE 'False' END as isPublished
	from articles 
    join articles_elements on articles.id = articles_elements.article_id 
    join elements on articles_elements.element_id = elements.id 
    group by articles.id;`

    let data = await pool.query(sqlQuery);
    return data;
}