const util = require('util')
var mysql = require('mysql');
const dbConfig = require('../../config.json');

var pool = mysql.createPool({
    connectionLimit: dbConfig.CONN_LIMIT,
    host: dbConfig.RDS_HOSTNAME,
    user: dbConfig.RDS_USERNAME,
    password: dbConfig.RDS_PASSWORD,
    database: dbConfig.RDS_DATABASE
});

pool.getConnection((err, connection) => {

    if (err) {
        console.log(err)
        throw err;
    }

    if (connection) connection.release()

    return
})

// Promisify for Node.js async/await.
pool.query = util.promisify(pool.query)

module.exports = pool