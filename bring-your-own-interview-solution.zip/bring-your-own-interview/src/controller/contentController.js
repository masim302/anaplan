const express = require('express');
const contentRouter = express.Router();
const { getContents } = require('../dbServices/getContentService')
contentRouter.route('/')
    .get(async (req, res, next) => {
        let isDecode = req.query.decode;
        try {
            let data = await getContents();
            if (isDecode != undefined)
                data = decodeHTML(data);
            res.json(data);
        } catch (err) {
            console.log(err);
            res.status(500).send('Unbale to fetch data');
        }
    })


function decodeHTML(data) {
    data.forEach(element => {
        if (element.html_content != undefined) {
            element.html_content = decodeURIComponent(element.html_content)
        }
    });
    return data;
}

module.exports = contentRouter;