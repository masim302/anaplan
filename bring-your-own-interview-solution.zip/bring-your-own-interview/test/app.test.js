const { expect } = require("chai");
const chai = require("chai");
const chaiHttp = require("chai-http");
chai.use(chaiHttp);

const app = require('../index');


describe('App Test', () => {
    it('Should return 200 ', (done) => {
        chai.request(app)
            .get('/content')
            .end((err, res) => {
                if (err)
                    console.log(err)
                // console.log(res);
                expect(res.statusCode).to.equal(200);
                expect(res).to.have.property('body');
                done();
            });


    })
})